<?php
// debug.php
phpinfo();
?>