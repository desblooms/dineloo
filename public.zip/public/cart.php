<?php include_once '../php/config/constants.php'; include_once '../php/core/Session.php'; ?> 
