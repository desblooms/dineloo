This directory stores user-uploaded content 
