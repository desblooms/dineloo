// Utility functions 
