// Core functionality for the application 
