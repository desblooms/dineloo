// Payment processing functions 
