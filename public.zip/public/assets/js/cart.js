// Cart operations and management 
