// Real-time update functionality 
