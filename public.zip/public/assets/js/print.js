// Printing functions for receipts and KOT 
