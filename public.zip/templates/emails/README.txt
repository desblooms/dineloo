This directory stores email templates 
