This directory stores PDF templates 
