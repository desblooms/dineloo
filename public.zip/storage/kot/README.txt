This directory stores KOT templates 
