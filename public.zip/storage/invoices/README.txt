This directory stores generated invoices 
