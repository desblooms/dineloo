module.exports = { 
  content: ["./public/**/*.{php,html,js}"], 
  theme: { 
    extend: {}, 
  }, 
  plugins: [], 
} 
